<?php return array('version' => 'e680f58e42701d02a784');
